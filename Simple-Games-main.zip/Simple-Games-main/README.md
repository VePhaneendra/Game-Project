# Simple Games
A semester-3 project named "Simple Games" contains some simple and easy games. This project uses concepts of Javascript and Bootstrap 5.
## Language used: HTML, CSS, Javascript

  
## Features

- Total 4 various & easy games 
1. Tic-Tac-Toe 
2. Word Scramble Game
3. Rock Paper Scissor
4. Word Typing Game
  
## Project Made By


- [Tulsi Lukhi](https://github.com/Tulsi011)
- [Parangi Rathod](https://github.com/Parangi-27)

## Project Demo Link

[Watch demo video here](https://drive.google.com/drive/folders/1CyE9Myn0qcnlToZr-gp3zXVnyqzIlapQ?usp=sharing)

## Note
This website is created as our Semester-3 project.
  
